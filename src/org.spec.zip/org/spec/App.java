package org.spec;

import org.spec.container.Container;
import org.spec.specification.ISpecification;
import org.spec.specification.NotSpecification;
import org.spec.specification.OrSpecification;
import org.spec.specification.Specification;
import org.spec.specification.operation.*;

import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

public class App {

  public static Container makeExampleContainer() {
    Random random = new Random();
    return new Container(
        UUID.randomUUID(),
        random.nextBoolean(),
        random.nextDouble() * 100.0,
        random.nextBoolean(),
        random.nextDouble() * 20_000.0);
  }

  public static void main(String[] args) {
    ArrayList<Container> containers = new ArrayList<>();
    for (int i = 0; i < 2500; i++) {
      containers.add(makeExampleContainer());
    }

    ISpecification specification = new Specification();
    // All selected containers must suppoert a weight of at least 15,000 lbs.
    specification.addChildren(new WeightOperation(15_000, EqualityComparison.GreaterThanEqualTo));

    // They must also satisfy one of the three below conidtions
    Specification complexSubSpec = new OrSpecification();
    // Not be (SANITARY OR PADDED)
    Specification complexOptionA =
        new NotSpecification(
            new OrSpecification(new SanitationOperation(), new PaddingSpecification()));
    // Be (SANITARY AND TEMPERATURE < 5 degrees)
    Specification complexOptionB =
        new Specification(
            new SanitationOperation(), new TemperatureOperation(5.0, EqualityComparison.LessThan));
    // Be (NOT SANITARY AND TEMPERATURE > 95 degrees)
    Specification complexOptionC =
        new Specification(
            new NotSpecification(new SanitationOperation()),
            new TemperatureOperation(95.0, EqualityComparison.GreaterThan));
    complexSubSpec.addChildren(complexOptionA, complexOptionB, complexOptionC);

    specification.addChildren(complexSubSpec);

    for (Container container : containers) {
      if (specification.isSatisfiedBy(container)) {
        System.out.println(container);
      }
    }
  }
}
