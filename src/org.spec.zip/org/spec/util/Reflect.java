package org.spec.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Reflect {
  public static Field[] getAllFields(Class<?> type) {
    return getAllFields(new ArrayList<>(), type);
  }

  public static Field[] getAllFields(List<Field> fields, Class<?> type) {
    do {
      fields.addAll(0, Arrays.asList(type.getDeclaredFields()));
      type = type.getSuperclass();
    } while (type != null);

    return fields.toArray(new Field[0]);
  }
}
