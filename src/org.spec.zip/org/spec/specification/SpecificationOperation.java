package org.spec.specification;

public class SpecificationOperation {
}
