package org.spec.specification;

import org.spec.container.Container;

import java.util.List;

public interface ISpecification {
  boolean isSatisfiedBy(Container container);

  boolean isGeneralizationOf(ISpecification specification);

  ISpecification and(ISpecification... others);

  ISpecification or(ISpecification... others);

  ISpecification remainderUnsatisfiedBy(Container container);

  List<? extends ISpecification> getChildren();

  void addChildren(ISpecification... children);

  void removeChildren(ISpecification... children);
}
