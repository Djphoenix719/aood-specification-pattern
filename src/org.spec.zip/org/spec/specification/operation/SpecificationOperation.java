package org.spec.specification.operation;

import org.spec.specification.Specification;

public abstract class SpecificationOperation extends Specification {}
