package org.spec.specification.operation;

public enum EqualityComparison {
  EqualTo,
  LessThan,
  LessThanEqualTo,
  GreaterThan,
  GreaterThanEqualTo,
}
