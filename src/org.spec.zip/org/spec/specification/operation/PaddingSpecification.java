package org.spec.specification.operation;

import org.spec.container.Container;

public class PaddingSpecification extends SpecificationOperation {
  @Override
  public boolean isSatisfiedBy(Container container) {
    return container.isPadded();
  }
}
