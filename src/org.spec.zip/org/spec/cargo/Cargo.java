package org.spec.cargo;

public class Cargo {
}
